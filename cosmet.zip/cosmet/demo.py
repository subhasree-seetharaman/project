from logging import debug
from flask import Flask,render_template
from flask_pymongo import PyMongo
app=Flask(__name__)
app.config["MONGO_URI"] = "mongodb://127.0.0.1:27017/mydb"
mongo = PyMongo(app)
todo_collection = mongo.db.todo
@app.route("/")
def home():
    return render_template("indo.html")
@app.route("/")
def sign():
    return render_template("signup.html")
# @app.route("/signup", methods=['GET'])
# def show_data():
#     if request.method == 'GET':
#         firstname = request.args.get("x")
#         lastname = request.args.get("y")
#         email = request.args.get("z")
#     if firstname != "" and lastname != "" and email != "":
#         todo = todo_collection.insert_one({"firstname": firstname, "lastname": lastname, "email": email})
#         return ("data added to the database")

#     else:
#         return ("Kindly fill the form")
if __name__ =='__main__':
    app.run(debug=True)